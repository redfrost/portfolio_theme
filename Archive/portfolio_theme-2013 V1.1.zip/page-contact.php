<?php
/*
Template Name: Contact Page
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'contact'); ?>