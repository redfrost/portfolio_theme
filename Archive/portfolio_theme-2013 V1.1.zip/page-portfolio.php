<?php
/*
Template Name: Portfolio 1 Up Banner
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'portfolio'); ?>