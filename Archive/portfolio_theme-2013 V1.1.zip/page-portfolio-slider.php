<?php
/*
Template Name: Portfolio Slider
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'portfolio-slider'); ?>