<?php
/*
Template Name: Portfolio List
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'portfolio-list'); ?>